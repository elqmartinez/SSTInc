//
//  cmonApp.swift
//  cmon
//
//  Created by Eva Martinez on 4/9/23.
//

import SwiftUI

@main
struct cmonApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView(a: ["spagh"], ind: 0)
        }
    }
}
